"""Context Manager exercises"""


class cd:
    """Context manager that temporarily changes directories."""


class Timer:
    """Context manager to time a code block."""


class suppress:
    """Context manager that suppresses exceptions of given type."""


class stdin_spy:
    """Context manager capturing everything from standard input"""


class make_file:
    """Context manager that creates a temporary file existing within ``with`` block."""
