"""Tests for context manager exercises"""
import os
from os.path import abspath, exists, realpath
from shutil import rmtree
from tempfile import mkdtemp
from types import TracebackType
from contextlib import contextmanager, redirect_stdout
from io import StringIO
import sys
from time import perf_counter
import unittest

from context_managers import (
    cd,
    Timer,
    suppress,
    stdin_spy,
    make_file,
)


class CDTests(unittest.TestCase):

    """Tests for cd."""

    def setUp(self):
        self.dirs = []
        os.chdir(self.get_temp_dir())

    def tearDown(self):
        for directory in self.dirs:
            rmtree(directory, ignore_errors=True)

    def get_temp_dir(self):
        """Return the canonical path to a new temporary directory."""
        directory = realpath(mkdtemp())
        self.dirs.append(directory)
        return directory

    def test_directory_changed(self):
        directory = self.get_temp_dir()
        original = os.getcwd()
        with cd(directory):
            self.assertEqual(abspath(os.getcwd()), abspath(directory))
        self.assertEqual(abspath(os.getcwd()), abspath(original))

    def test_changing_directory_still_works(self):
        directory = self.get_temp_dir()
        directory2 = self.get_temp_dir()
        original = os.getcwd()
        with cd(directory):
            self.assertEqual(abspath(os.getcwd()), abspath(directory))
            os.chdir(directory2)
            self.assertEqual(abspath(os.getcwd()), abspath(directory2))
        self.assertEqual(abspath(os.getcwd()), abspath(original))

    def test_no_directory_change(self):
        original = os.getcwd()
        with cd(original):
            self.assertEqual(abspath(os.getcwd()), abspath(original))
        self.assertEqual(abspath(os.getcwd()), abspath(original))

    def test_changes_even_with_exceptions(self):
        directory = self.get_temp_dir()
        original = os.getcwd()
        with self.assertRaises(ValueError):
            with cd(directory):
                raise ValueError
        self.assertEqual(abspath(os.getcwd()), abspath(original))
        with self.assertRaises(SystemExit):
            with cd(directory):
                raise SystemExit
        self.assertEqual(abspath(os.getcwd()), abspath(original))

    def test_reentrant(self):
        directory = self.get_temp_dir()
        directory2 = self.get_temp_dir()
        original = os.getcwd()
        with cd(directory):
            with cd(directory2):
                self.assertEqual(abspath(os.getcwd()), abspath(directory2))
            self.assertEqual(abspath(os.getcwd()), abspath(directory))
        self.assertEqual(abspath(os.getcwd()), abspath(original))

    def test_directory_not_deleted_afterward(self):
        directory = self.get_temp_dir()
        with cd(directory):
            self.assertTrue(exists(directory), "given directory was deleted!")
        self.assertTrue(exists(directory), "given directory was deleted!")
        with cd(directory):
            with open('hello.txt', mode='wt') as f:
                f.write('hello!')
            filename = abspath('hello.txt')
        self.assertTrue(exists(filename), "file in directory was deleted!")

    def test_initialization_before_context_entering(self):
        directory = self.get_temp_dir()
        new_original = self.get_temp_dir()
        old_original = os.getcwd()
        dirs = cd(directory)
        self.assertEqual(abspath(os.getcwd()), abspath(old_original))
        os.chdir(new_original)
        with dirs:
            self.assertEqual(abspath(os.getcwd()), abspath(directory))
        self.assertEqual(abspath(os.getcwd()), abspath(new_original))

    @unittest.skip("cd decorator")
    def test_as_decorator(self):
        directory = self.get_temp_dir()
        directory2 = self.get_temp_dir()
        original = os.getcwd()
        @cd(directory)
        def func1():
            return os.getcwd()
        @cd(directory2)
        def func2():
            return [os.getcwd(), func1(), os.getcwd()]
        def func3():
            return [os.getcwd(), *func2(), os.getcwd()]
        result = func3()
        self.assertEqual(len(result), 5)
        self.assertEqual(abspath(result[0]), abspath(original))
        self.assertEqual(abspath(result[1]), abspath(directory2))
        self.assertEqual(abspath(result[2]), abspath(directory))
        self.assertEqual(abspath(result[3]), abspath(directory2))
        self.assertEqual(abspath(result[4]), abspath(original))


class TimerTests(unittest.TestCase):

    """Tests for Timer."""

    _baseline = None

    @staticmethod
    def get_baseline(count=100):
        times = 0
        for i in range(count):
            with Timer() as timer:
                sleep(0)
            times += timer.elapsed
        return times / count

    def assertTimeEqual(self, actual, expected):
        if self._baseline is None:
            self._baseline = self.get_baseline()
        self.assertAlmostEqual(actual, self._baseline+expected, delta=0.15)

    def test_short_time(self):
        with Timer() as timer:
            sleep(0.1)
        self.assertGreater(timer.elapsed, 0.009)
        self.assertLess(timer.elapsed, 0.8)

    def test_very_short_time(self):
        with Timer() as timer:
            pass
        self.assertTimeEqual(timer.elapsed, 0)

    def test_two_timers(self):
        with Timer() as timer1:
            sleep(0.005)
            with Timer() as timer2:
                sleep(0.05)
            sleep(0.05)
        self.assertLess(timer2.elapsed, timer1.elapsed)

    def test_reusing_same_timer(self):
        timer = Timer()
        with timer:
            sleep(0.01)
        elapsed1 = timer.elapsed
        with timer:
            sleep(0.2)
        elapsed2 = timer.elapsed
        self.assertLess(elapsed1, elapsed2)


def sleep(duration):
    now = perf_counter()
    end = now + duration
    while now < end:
        now = perf_counter()


class SuppressTests(unittest.TestCase):

    """Tests for suppress."""

    def test_works_when_no_exception_raised(self):
        with suppress(Exception):
            x = 4
        self.assertEqual(x, 4)

    def test_suppress_specific_exception(self):
        with suppress(ValueError):
            x = 1
            int('hello')
            x = 2
        self.assertEqual(x, 1)
        with suppress(TypeError):
            x = 3
            int(None)
            x = 4
        self.assertEqual(x, 3)

    def test_keyerror_and_index_error(self):
        with suppress(KeyError):
            my_dict = {'key': 'value'}
            my_dict[4]
        self.assertEqual(my_dict, {'key': 'value'})
        with suppress(IndexError):
            my_list = ['item']
            my_list[1]
            self.assertEqual(my_list, ['item'])

    def test_suppresses_parent_exceptions(self):
        with suppress(LookupError):
            my_dict = {'key': 'value'}
            my_dict[4]
        self.assertEqual(my_dict, {'key': 'value'})
        with suppress(LookupError):
            my_list = ['item']
            my_list[1]
            self.assertEqual(my_list, ['item'])

    def test_does_not_suppress_other_exceptions(self):
        with self.assertRaises(KeyError):
            with suppress(IndexError):
                my_dict = {'key': 'value'}
                my_dict[4]
            self.assertEqual(my_dict, {'key': 'value'})
        with self.assertRaises(IndexError):
            with suppress(KeyError):
                my_list = ['item']
                my_list[1]
                self.assertEqual(my_list, ['item'])

    def test_catches_any_number_of_exceptions(self):
        with suppress(ValueError, TypeError):
            int('hello')
        with suppress(IndexError, TypeError):
            int(None)
        with self.assertRaises(KeyError):
            with suppress(IndexError, TypeError):
                {0: 1}[1]
        with suppress(ValueError, SystemError, IndexError, TypeError):
            ['item'][1]

    def test_allows_exception_to_be_viewed(self):
        with suppress(LookupError) as suppressed:
            my_dict = {'key': 'value'}
            my_dict[4]
        self.assertEqual(type(suppressed.exception), KeyError)
        self.assertEqual(type(suppressed.traceback), TracebackType)


class StdinSpyTests(unittest.TestCase):

    """Tests for stdin_spy."""

    def test_no_input(self):
        with stdin_spy() as spied_stdin:
            self.assertEqual(spied_stdin.getvalue(), '')

    def test_user_prompted(self):
        with redirect_stdout(StringIO()) as stdout:
            with patch_stdin("Trey\npurple\n"):
                with stdin_spy() as spied_stdin:
                    name = input("What's your name? ")
                    color = input("What's your favorite color? ")
        self.assertEqual(spied_stdin.getvalue(), "Trey\npurple\n")
        self.assertEqual(name, "Trey")
        self.assertEqual(color, "purple")
        self.assertEqual(
            stdout.getvalue(),
            "What's your name? What's your favorite color? ",
        )

@contextmanager
def patch_stdin(text):
    real_stdin = sys.stdin
    sys.stdin = StringIO(text)
    try:
        yield sys.stdin
    except EOFError as e:
        raise AssertionError("Read more input than was given") from e
    finally:
        sys.stdin = real_stdin


class MakeFileTests(unittest.TestCase):

    """Tests for make_file."""

    def test_file_created(self):
        with make_file() as filename:
            with open(filename, mode='rt') as my_file:
                contents = my_file.read()
            self.assertEqual(contents, '')

    def test_file_writeable(self):
        with make_file() as filename:
            with open(filename, mode='wt') as my_file:
                my_file.write('hello!')
            with open(filename, mode='rt') as my_file:
                contents = my_file.read()
            self.assertEqual(contents, 'hello!')

    def test_file_deleted_afterward(self):
        with make_file() as filename:
            self.assertTrue(os.path.isfile(filename))
        self.assertFalse(os.path.isfile(filename))

    def test_file_deleted_when_storing_context_manager_object(self):
        context = make_file()
        with context as filename:
            self.assertTrue(os.path.isfile(filename))
        self.assertFalse(os.path.isfile(filename))

    def test_file_deleted_even_after_exception(self):
        class CustomException(ValueError): pass
        with self.assertRaises(CustomException):
            with make_file() as filename:
                self.assertTrue(os.path.isfile(filename))
                raise CustomException("Something went wrong here!")
        self.assertFalse(os.path.isfile(filename))

    def test_allow_file_to_have_initial_contents(self):
        with make_file(contents="hello there!") as filename:
            with open(filename, mode='rt') as my_file:
                contents = my_file.read()
            self.assertEqual(contents, 'hello there!')

    def test_allow_specifying_directory(self):
        from tempfile import mkdtemp  # This may be a hint
        directory = mkdtemp()
        with make_file(contents="hi\nthere!", directory=directory) as filename:
            self.assertEqual(os.path.dirname(filename), directory)
            with open(filename) as my_file:
                self.assertEqual(my_file.read(), 'hi\nthere!')

    def test_allow_specifying_file_options(self):
        with make_file(contents=b"hi\nthere!", mode='wb') as filename:
            with open(filename, mode='rt') as my_file:
                self.assertEqual(my_file.read(), 'hi\nthere!')
        with make_file(contents="hi\nthere!", encoding='utf-16-le') as filename:
            with open(filename, encoding='utf-16-le') as my_file:
                self.assertEqual(my_file.read(), 'hi\nthere!')
        with make_file(contents="hi\nthere!", newline='\r') as filename:
            with open(filename, mode='rt', newline='') as my_file:
                self.assertEqual(my_file.read(), 'hi\rthere!')


if __name__ == "__main__":
    from helpers import error_message
    error_message()
