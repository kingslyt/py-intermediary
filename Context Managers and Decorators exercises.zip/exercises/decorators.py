"""Decorator exercises"""


def count_calls():
    """Record calls to the given function."""


def positional_only():
    """Specify arguments to a function positionally only."""


def coalesce_all():
    """Decorator to coalesces arguments to default when sentinel is given."""


def ratelimit():
    """Raise exception if decorated function is called too often."""


def allow_snake():
    """Add camelCase versions of snake_case methods and vice versa on cls."""


def overload():
    """Allow functions to be overloaded based on arguments count and their types."""


def at():
    """Chain all given decorators together."""


def record_calls():
    """Recording number of times a decorated function is called."""
