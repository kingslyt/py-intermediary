TESTS = {
    "cd": "context_managers_test.CDTests",
    "make_file": "context_managers_test.MakeFileTests",
    "stdin_spy": "context_managers_test.StdinSpyTests",
    "suppress": "context_managers_test.SuppressTests",
    "Timer": "context_managers_test.TimerTests",
    "allow_snake": "decorators_test.AllowSnakeTests",
    "at": "decorators_test.AtTests",
    "coalesce_all": "decorators_test.CoalesceAllTests",
    "count_calls": "decorators_test.CountCallsTests",
    "overload": "decorators_test.OverloadTests",
    "positional_only": "decorators_test.PositionalOnlyTests",
    "ratelimit": "decorators_test.RateLimitTests",
    "record_calls": "decorators_test.RecordCallsTests",
    "is_ok": "initial_test.InitialTests"
}

MODULES = {
    "context_managers": [
        "cd",
        "make_file",
        "stdin_spy",
        "suppress",
        "Timer"
    ],
    "decorators": [
        "allow_snake",
        "at",
        "coalesce_all",
        "count_calls",
        "overload",
        "positional_only",
        "ratelimit",
        "record_calls"
    ],
    "initial": [
        "is_ok"
    ]
}
